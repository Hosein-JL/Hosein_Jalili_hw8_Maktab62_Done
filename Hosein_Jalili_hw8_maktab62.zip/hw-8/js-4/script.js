$(document).ready(function() {
    let app = new App(userData)
    app.setup()
})